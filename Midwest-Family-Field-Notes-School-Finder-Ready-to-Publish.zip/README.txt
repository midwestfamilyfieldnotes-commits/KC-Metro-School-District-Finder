MIDWEST FAMILY FIELD NOTES — SCHOOL DISTRICT RESOURCE FINDER

READY TO PUBLISH

Fastest free option: GitHub Pages

1. Create a free GitHub account, if needed.
2. Create a new public repository named:
   school-district-resource-finder
3. Choose “uploading an existing file.”
4. Upload index.html from this folder.
5. Click “Commit changes.”
6. Open Settings > Pages.
7. Under “Build and deployment,” choose:
   Source: Deploy from a branch
   Branch: main
   Folder: / (root)
8. Click Save.

GitHub will display the public website address after publishing.

TO UPDATE DISTRICTS
Open index.html in a code editor and find:
const districts=

Each district includes its direct links. Replace a URL between quotation marks,
save the file, and upload the updated index.html to GitHub.

The included spreadsheet is the working source list for district links.
